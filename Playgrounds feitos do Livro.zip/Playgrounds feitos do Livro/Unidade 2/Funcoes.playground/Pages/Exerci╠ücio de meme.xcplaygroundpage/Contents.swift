/*:
## Meme funcional

 Pense em uma música ou um meme divertido que você ouviu ou viu recentemente e que tenha partes repetitivas. Por exemplo:

- Uma música com um refrão que se repete.
- Um meme que repete uma palavra ou frase.
- Uma música que repete um verso várias vezes.
 
 Escreva a música ou o meme usando instruções `print`. Depois, procure padrões e repetições e escolha grupos de linhas para combinar em funções. Este exercício é livre, então você pode fazer o que quiser.
 */

/*:
A seguir, deixe o meme do seu jeito.

[Anterior](@previous)  |  página 11 de 12  |  [Na sequência: Meme pessoal](@next)
 */
func estrofe1() {
    print("Oh oh oh oh oh oh I'm in love with Judas, Judas")
    print("Oh oh oh oh oh oh I'm in love with Judas, Judas")
}
func estrofe2() {
    print("Judas, Judas")
    print("Judas, Judas")
    print("Judas, Judas")
    print("Judas, Judas")
    print("Gaga")
}
func estrofe3() {
    print("When he comes to me, I am ready")
    print("I'll wash his feet with my hair if he needs")
    print("Forgive him when his tongue lies through his brain")
    print("Even after three times, he betrays me")
}
func estrofe4() {
    print("I'll bring him down")
    print("Bring him down, down")
    print("A king with no crown")
    print("A king with no crown")
}
func estrofe5() {
    print("I'm just a Holy Fool, oh baby it's so cruel")
    print("But I'm still in love with Judas, baby")
    print("I'm just a Holy Fool, oh baby it's so cruel")
    print("But I'm still in love with Judas, baby")
}
func estrofe6() {
    print("I couldn't love a man so purely")
    print("Even darkness forgave his goofy way")
    print("I've learned love is like a brick")
    print("You can build a house or sink a dead body")
}
func estrofe7() {
    print("In the most Biblical sense, I am beyond repentance")
    print("Fame hooker, prostitute wench, vomits her mind")
    print("But in the cultural sense I just speak in future tense")
    print("Judas kiss me if offenced, or wear an ear condom next time")
}
func estrofe8() {
    print("I wanna love you but something is putting me away from you")
    print("Jesus is my virtue and Judas is the demon I claim to I claim to")
}

func refrao() {
    estrofe1()
    estrofe2()
}
 

estrofe1()
print("~")
estrofe2()
print("~")
estrofe2()
print("~")
estrofe3()
print("~")
estrofe4()
print("~")
estrofe5()
print("~")
refrao()
print("~")
estrofe6()
print("~")
estrofe4()
print("~")
estrofe5()
print("~")
estrofe1()
print("~")
print("Ew!")
print("~")
estrofe7()
print("~")
estrofe8()
print("~")
estrofe5()
print("~")
refrao()




