/*:
## Meme pessoal

 Copie as funções que você criou no exercício anterior para esta página ou formule-as novamente para praticar. Ou então crie um novo conjunto de funções.

 Dentro de uma das funções, faça alterações que mudem o significado ou deixem o texto mais engraçado. Você pode usar o seu nome ou o de um amigo, mudar uma palavra para criar uma rima ou fazer experiências.
 */
