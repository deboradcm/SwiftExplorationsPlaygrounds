/*:
## Exercício – Lista de compras

 As constantes abaixo representam alguns itens que podem ser adicionados a uma lista de compras:
 */
let eggs = "Ovos"
let milk = "Leite"
let cheese = "Queijo"
let bread = "Pão"
let rice = "Arroz"
let newLine = "\n"
//:  - callout(Exercício): Crie uma variável string com um valor inicial de `""`. Adicione cada item constante acima à lista, um de cada vez. Adicione uma `newLine` entre os itens. Lembre que você pode combinar duas strings usando o operador `+`.
/*:
[Anterior](@previous)  |  página 12 de 13  |  [Na sequência: Exercício – 501](@next)
 */
var lista = ""
lista += eggs
lista += newLine
lista += milk
lista += newLine
lista += cheese
lista += newLine
lista += bread
lista += newLine
lista += rice

